		
		</div>
	</div>
	</div>

	<footer>
	<div class="container" id="footer">
	<div class="row">
	<div class="col-md-12">
		&copy; <?php echo date("Y"); ?>. All rights reserved.
		<!-- Do not remove this copyright notice! -->
		Powered by <a href="http://www.exchangerix.com" target="_blank">Exchangerix</a> v2.0
		<!-- ------------------------------------ -->
	</div>
	</div>
	</div>
	</footer>

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
	<script type="text/javascript" src="js/moment.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
	<script type="text/javascript" src="js/lightbox.js"></script>
	<script type="text/javascript" src="js/exchangerix_scripts.js"></script>

</body>
</html>