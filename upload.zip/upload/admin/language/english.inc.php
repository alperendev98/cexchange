<?php
/*******************************************************************\
 * Exchangerix v2.0
 * http://www.exchangerix.com
 *
 * Copyright (c) 2018 Exchangerix Software. All rights reserved.
 * ------------ Exchangerix IS NOT FREE SOFTWARE --------------
\*******************************************************************/

/* MENU */
define ('CBE_A_MENU_HOME', 'Dashboard');
define ('CBE_A_MENU_STORES', 'Stores');
define ('CBE_A_MENU_COUPONS', 'Coupons');
define ('CBE_A_MENU_DEALS', 'Deals');
define ('CBE_A_MENU_CASHBACK', 'Cashback');
define ('CBE_A_MENU_CHISTORY', 'Click History');
define ('CBE_A_MENU_CATEGORIES', 'Categories');
define ('CBE_A_MENU_COUNTRIES', 'Countries');
define ('CBE_A_MENU_REVIEWS', 'Reviews');
define ('CBE_A_MENU_INVITATIONS', 'Invitations');
define ('CBE_A_MENU_MCREDIT', 'Manual Credit');
define ('CBE_A_MENU_CSV_IMPORT', 'Upload CSV-Report');
define ('CBE_A_MENU_MESSAGES', 'Messages');
define ('CBE_A_MENU_NETWORKS', 'Affiliate Networks');
define ('CBE_A_MENU_PMETHODS', 'Payment Methods');
define ('CBE_A_MENU_NEWS', 'News');
define ('CBE_A_MENU_CONTENT', 'Content');
define ('CBE_A_MENU_ETEMPLATES', 'Email Templates');
define ('CBE_A_MENU_EMAIL_USERS', 'Email Members');
define ('CBE_A_MENU_EMAIL_API', 'API');
define ('CBE_A_MENU_EMAIL_SETTINGS', 'Settings');
define ('CBE_A_MENU_LOGOUT', 'Logout');

?>